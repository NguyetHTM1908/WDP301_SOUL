import { Stack } from "expo-router";

export default function AuthLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="login" />
      <Stack.Screen name="register" />
      <Stack.Screen name="forgot" />
      <Stack.Screen name="verify" />
      <Stack.Screen name="recovery" />
      <Stack.Screen name="congrats" />
    </Stack>
  );
}
